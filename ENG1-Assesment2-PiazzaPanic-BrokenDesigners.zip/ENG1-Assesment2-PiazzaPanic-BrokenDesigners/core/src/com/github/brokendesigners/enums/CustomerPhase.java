package com.github.brokendesigners.enums;

/***
 * Created Enum
 */
public enum CustomerPhase {
    SPAWNING,
    MOVING_TO_STATION,
    WAITING,
    LEAVING,
    DESPAWNING,
    UNLOADING
}
