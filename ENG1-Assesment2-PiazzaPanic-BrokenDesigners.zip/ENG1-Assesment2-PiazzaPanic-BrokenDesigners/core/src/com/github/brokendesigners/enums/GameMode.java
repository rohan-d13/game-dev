package com.github.brokendesigners.enums;
/***
 * Created Enum
 */
public enum GameMode {
    SCENARIO,
    ENDLESS
}