package com.github.brokendesigners.item;

public class TestItem extends Item{

    public TestItem(String n) {
        super(n);
    }
}
